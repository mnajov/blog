import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';
import { BaseEntity } from 'src/commond/base/base.entity';

export type UserDocument = HydratedDocument<User>;
@Schema()
export class User extends BaseEntity {
  @Prop({ type: String, require: true })
  login: string;
  @Prop({ type: String``, required: true })
  password: string;
  @Prop({ type: String, required: true })
  username: string;
  @Prop({ type: String, required: true })
  lang: string;
}

export const userSchema = SchemaFactory.createForClass(User);
