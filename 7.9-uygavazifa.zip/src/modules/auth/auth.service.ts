import { Injectable, UnauthorizedException } from '@nestjs/common';
import { loginAuthDto } from './dto/login-auth.dto';
import { UserService } from '../user/user.service';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(
    private readonly userservice: UserService,
    private readonly jwtService: JwtService,
  ) {}
  async login(dto: loginAuthDto) {
    const user = await this.userservice.findLogin(dto.login);
    if (user && user.password === dto.password) {
      return {
        data: user,
        accToken: await this.jwtService.signAsync({
          login: user.login,
          id: user.id,
        }),
      };
    }
    throw new UnauthorizedException('password or login is incorrect');
  }
}
