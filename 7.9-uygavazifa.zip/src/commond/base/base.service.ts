import { Injectable } from '@nestjs/common';
import { BaseRepository } from './base.repository';

@Injectable()
export class BaseService<Entity, CDto, UDto> {
  constructor(
    private readonly baseRepostry: BaseRepository<Entity, CDto, UDto>,
  ) {}
  async create(createBaseDto: CDto): Promise<Entity> {
    return await this.baseRepostry.create(createBaseDto);
  }

  async findAll(): Promise<Array<Entity>> {
    return await this.baseRepostry.findAll();
  }

  async findOne(id: string): Promise<Entity> {
    return await this.baseRepostry.findById(id);
  }

  async update(id: string, updateBaseDto: UDto) {
    return await this.baseRepostry.update(id, updateBaseDto);
  }

  async remove(id: string) {
    return await this.baseRepostry.delete(id);
  }
}
